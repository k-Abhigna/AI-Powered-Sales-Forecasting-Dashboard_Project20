# Power BI Dashboard — Build Instructions

A native `.pbix` file is a binary format produced only by Power BI Desktop, so it can't
be generated programmatically outside of it. This file gives you everything needed to
rebuild the dashboard shown in `images/dashboard.png` in about 10–15 minutes.

## 1. Import Data

In Power BI Desktop: **Get Data → Text/CSV** → import both:
- `outputs/predictions.csv` (Date, Sales, Forecast)
- `data/sales_data.csv` (Date, Store, Product, Region, Promotion, Holiday, Sales)

Relate them on **Date** (and optionally Store/Product/Region if you keep those columns
in the predictions export).

## 2. Suggested DAX Measures

```dax
Total Sales = SUM(sales_data[Sales])

Total Forecast = SUM(predictions[Forecast])

Avg Daily Sales =
AVERAGEX ( VALUES ( sales_data[Date] ), CALCULATE ( SUM ( sales_data[Sales] ) ) )

Forecast Error = ABS ( [Total Sales] - [Total Forecast] )

Forecast Accuracy % =
1 - DIVIDE ( [Forecast Error], [Total Sales], 0 )

YoY Sales Growth % =
VAR CurrentSales = [Total Sales]
VAR PriorYearSales =
    CALCULATE ( [Total Sales], SAMEPERIODLASTYEAR ( sales_data[Date] ) )
RETURN DIVIDE ( CurrentSales - PriorYearSales, PriorYearSales, 0 )
```

## 3. Pages & Visuals

**Page 1 — Overview**
- KPI cards: Total Sales, Avg Daily Sales, Forecast Accuracy %, YoY Growth %
- Line chart: Sales & Forecast by Date
- Donut chart: Sales by Region
- Bar chart: Sales by Product
- Slicers: Date range, Store, Region

**Page 2 — Forecast Drill-through**
- Line chart: Actual vs Forecast at daily/weekly grain
- Table: Date, Store, Product, Sales, Forecast, Forecast Error
- Drill-through filter: Store or Product from Page 1

**Page 3 — Store Performance**
- Matrix: Store x Month with conditional formatting (heat map) on Sales
- Bar chart: Top/bottom performing stores
- Card: Store-level Forecast Accuracy %

## 4. Formatting Notes

- Color palette used in the reference mockup: `#1F618D` (primary blue), `#E67E22`
  (forecast/accent orange), `#117864` (secondary teal).
- Use a consistent SLA/target reference line on trend charts where relevant.
- Add tooltips showing Forecast Error % on hover for the trend line visual.

Once built, save as `Sales_Forecasting_Dashboard.pbix` in this folder.
