"""
predict.py
------------
Loads the trained model and generates a forecast vs actual output CSV.
"""

import os
import joblib
import pandas as pd

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

model = joblib.load(f"{BASE}/models/sales_forecast_model.pkl")

df = pd.read_csv(f"{BASE}/data/processed_sales.csv")

drop_cols = ["Sales", "Date"]
X = df.drop(columns=[c for c in drop_cols if c in df.columns])

df["Forecast"] = model.predict(X)
df["Forecast"] = df["Forecast"].round(2)

out = df[["Date", "Sales", "Forecast"]] if "Date" in df.columns else df[["Sales", "Forecast"]]
out.to_csv(f"{BASE}/outputs/predictions.csv", index=False)

print("Predictions generated successfully ->", f"{BASE}/outputs/predictions.csv")
