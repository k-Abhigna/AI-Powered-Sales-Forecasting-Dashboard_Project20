"""
utils.py
----------
Shared plotting helpers.
"""

import matplotlib.pyplot as plt


def plot_forecast(actual, predicted, title="Actual vs Forecasted Sales"):
    plt.figure(figsize=(12, 6))
    plt.plot(actual, label="Actual", linewidth=1.5)
    plt.plot(predicted, label="Forecast", linewidth=1.5, linestyle="--")
    plt.title(title)
    plt.xlabel("Time")
    plt.ylabel("Sales")
    plt.legend()
    plt.tight_layout()
    plt.show()
