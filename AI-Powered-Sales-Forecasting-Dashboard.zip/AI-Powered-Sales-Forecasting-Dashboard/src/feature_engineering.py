"""
feature_engineering.py
------------------------
Create date-based and categorical features used by the model.
"""

import pandas as pd


def create_features(df: pd.DataFrame) -> pd.DataFrame:
    """Add calendar features derived from the Date column."""
    df = df.copy()
    df["Date"] = pd.to_datetime(df["Date"])

    df["Year"] = df["Date"].dt.year
    df["Month"] = df["Date"].dt.month
    df["Day"] = df["Date"].dt.day
    df["Weekday"] = df["Date"].dt.dayofweek
    df["WeekOfYear"] = df["Date"].dt.isocalendar().week.astype(int)
    df["IsWeekend"] = (df["Weekday"] >= 5).astype(int)

    return df


def encode_categoricals(df: pd.DataFrame) -> pd.DataFrame:
    """One-hot encode Store, Product, and Region."""
    df = df.copy()
    df = pd.get_dummies(df, columns=["Store", "Product", "Region"], drop_first=False)
    return df
