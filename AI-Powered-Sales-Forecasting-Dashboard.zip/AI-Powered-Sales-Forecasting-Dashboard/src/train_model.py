"""
train_model.py
----------------
Loads processed sales data, trains a RandomForestRegressor,
evaluates it, and saves the trained model + metrics.
"""

import os
import joblib
import numpy as np
import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

df = pd.read_csv(f"{BASE}/data/processed_sales.csv")

drop_cols = ["Sales", "Date"]
X = df.drop(columns=[c for c in drop_cols if c in df.columns])
y = df["Sales"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

model = RandomForestRegressor(
    n_estimators=80,
    max_depth=10,
    random_state=42,
    n_jobs=-1,
)

model.fit(X_train, y_train)

preds = model.predict(X_test)

mae = mean_absolute_error(y_test, preds)
rmse = np.sqrt(mean_squared_error(y_test, preds))
r2 = r2_score(y_test, preds)

print(f"MAE:  {mae:.2f}")
print(f"RMSE: {rmse:.2f}")
print(f"R2:   {r2:.4f}")

os.makedirs(f"{BASE}/models", exist_ok=True)
joblib.dump(model, f"{BASE}/models/sales_forecast_model.pkl")

with open(f"{BASE}/outputs/evaluation_metrics.txt", "w") as f:
    f.write("Model: RandomForestRegressor\n")
    f.write(f"MAE: {mae:.2f}\n")
    f.write(f"RMSE: {rmse:.2f}\n")
    f.write(f"R2 Score: {r2:.4f}\n")

print("Model and metrics saved.")
