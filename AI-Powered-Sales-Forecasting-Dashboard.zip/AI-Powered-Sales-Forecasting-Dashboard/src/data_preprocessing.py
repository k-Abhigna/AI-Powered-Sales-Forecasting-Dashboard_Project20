"""
data_preprocessing.py
----------------------
Load and clean the raw sales dataset.
"""

import pandas as pd


def load_data(path: str) -> pd.DataFrame:
    """Load raw sales data from a CSV file."""
    df = pd.read_csv(path)
    return df


def clean_data(df: pd.DataFrame) -> pd.DataFrame:
    """Basic cleaning: drop duplicates, handle missing values, fix dtypes."""
    df = df.drop_duplicates()

    # Forward-fill any missing values (rare in synthetic data, but kept for
    # robustness against real-world data drops)
    df = df.ffill()

    df["Date"] = pd.to_datetime(df["Date"])
    df["Promotion"] = df["Promotion"].astype(int)
    df["Holiday"] = df["Holiday"].astype(int)
    df["Sales"] = df["Sales"].astype(float)

    return df
