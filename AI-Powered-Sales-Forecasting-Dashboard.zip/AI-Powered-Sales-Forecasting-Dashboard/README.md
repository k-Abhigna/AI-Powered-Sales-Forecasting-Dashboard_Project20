# 📈 AI-Powered Sales Forecasting Dashboard

An end-to-end Machine Learning project that predicts future sales using historical sales data and visualizes business insights through an interactive Power BI dashboard.

![Dashboard Preview](images/dashboard.png)

---

## 🚀 Project Overview

This project combines Machine Learning and Business Intelligence to forecast future sales trends. It involves:

- Data Cleaning
- Feature Engineering
- Model Training (Random Forest Regressor)
- Sales Prediction
- Power BI Dashboard
- Business Insights

The objective is to help organizations improve demand planning and inventory management.

> **Note on data:** This repo uses a realistic **synthetic** retail dataset (15,000 rows across 10 stores, 8 products, and 4 regions with seasonal/holiday/promotion effects) generated for portfolio purposes. Swap in your own historical sales export to use this pipeline on real data — no code changes required beyond matching the column names.

---

## ✅ Features

- Data Cleaning & Missing Value Handling
- Calendar-based Feature Engineering (year, month, weekday, week-of-year, weekend flag)
- Categorical Encoding (Store, Product, Region)
- Random Forest Regression Model
- Model Evaluation (MAE, RMSE, R²)
- Forecast vs Actual Sales Comparison
- Interactive Power BI Dashboard

---

## 🛠 Tech Stack

| Technology | Usage |
|------------|-------|
| Python | Data Processing |
| Pandas | Data Manipulation |
| NumPy | Numerical Computing |
| Scikit-learn | Machine Learning |
| Matplotlib / Seaborn | Visualization |
| Power BI | Dashboard |
| Jupyter Notebook | Analysis & Experimentation |
| GitHub | Version Control |

---

## 📁 Project Structure

```
AI-Powered-Sales-Forecasting-Dashboard/
│
├── data/
│   ├── sales_data.csv          # Raw synthetic sales data
│   └── processed_sales.csv     # Cleaned + feature-engineered data
│
├── notebooks/
│   └── Sales_Forecasting.ipynb # Full EDA -> training -> evaluation workflow
│
├── src/
│   ├── data_preprocessing.py
│   ├── feature_engineering.py
│   ├── train_model.py
│   ├── predict.py
│   └── utils.py
│
├── models/
│   └── sales_forecast_model.pkl
│
├── dashboard/
│   └── Sales_Forecasting_Dashboard.pbix.md  # Build instructions (see below)
│
├── outputs/
│   ├── predictions.csv
│   └── evaluation_metrics.txt
│
├── images/
│   ├── dashboard.png
│   ├── forecast.png
│   └── workflow.png
│
├── requirements.txt
├── README.md
├── LICENSE
└── .gitignore
```

---

## 📊 Dataset Columns

| Column | Description |
|--------|-------------|
| Date | Transaction date |
| Store | Store identifier (10 stores) |
| Product | Product identifier (8 products) |
| Region | North / South / East / West |
| Promotion | 1 if item was on promotion |
| Holiday | 1 if the date was a public holiday |
| Sales | Units/value sold (target variable) |

---

## 🔄 Project Workflow

![Workflow](images/workflow.png)

Historical Data → Data Cleaning → Feature Engineering → Train ML Model → Sales Prediction → Power BI Dashboard

---

## 🤖 Machine Learning Model

**Model Used:** Random Forest Regressor (`n_estimators=80`, `max_depth=10`)

**Evaluation Metrics (on synthetic test data):**

| Metric | Value |
|--------|-------|
| MAE | 31.99 |
| RMSE | 41.21 |
| R² Score | 0.6319 |

> These numbers reflect the noise deliberately built into the synthetic dataset (to mimic real-world demand volatility). On your own real dataset, accuracy will vary — re-run `train_model.py` to regenerate these metrics.

---

## 📈 Forecast vs Actual

![Forecast](images/forecast.png)

---

## 📊 Power BI Dashboard

A native `.pbix` file can't be generated outside of Power BI Desktop, so this repo includes everything needed to rebuild it in a few minutes:

- `outputs/predictions.csv` — ready-to-import forecast vs actual data
- `dashboard/Sales_Forecasting_Dashboard.pbix.md` — page layout, suggested visuals, and DAX measures
- `images/dashboard.png` — a reference mockup of the target layout

**Suggested pages/visuals:**
- KPI cards: Total Sales, Avg Daily Sales, Forecast Accuracy, Store/Product counts
- Line chart: Forecast vs Actual Sales Trend
- Pie/Donut: Sales by Region
- Bar chart: Product-wise Sales Performance
- Line chart: Monthly Sales Trend
- Slicers: Store, Product, Region, Date range

---

## ⚙️ Installation

Clone the repository:
```bash
git clone https://github.com/yourusername/AI-Powered-Sales-Forecasting-Dashboard.git
cd AI-Powered-Sales-Forecasting-Dashboard
```

Install dependencies:
```bash
pip install -r requirements.txt
```

Run the pipeline:
```bash
python src/train_model.py
python src/predict.py
```

Or open the full walkthrough:
```bash
jupyter notebook notebooks/Sales_Forecasting.ipynb
```

---

## 🔮 Future Improvements

- XGBoost / LightGBM comparison
- Facebook Prophet for seasonal forecasting
- Deep Learning (LSTM) for sequence modeling
- Streamlit app for interactive what-if forecasting
- Azure ML / cloud deployment with scheduled retraining

---

## 👤 Author

Abhigna
- LinkedIn: https://linkedin.com/in/yourprofile
- GitHub: https://github.com/k-Abhigna
